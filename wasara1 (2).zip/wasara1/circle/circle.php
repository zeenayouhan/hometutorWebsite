<?php include "db.php" ;
$sql22="SELECT * FROM probability ;";
$result22 = $conn->query($sql22);

while($row = $result22->fetch_assoc()) {
		$a=$row["Full Details"];
		$b=$row["FirstdayFree"];
		$c=$row["ClassFee"];
		
}
$d=$a+$b+$c;?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>circular progress bar</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">
    <div class="piea"></div>
    <div class="pieb"></div>
    <div class="piec"></div>
  </div>

  <script src="circularProgressBar.js"></script>
  <script>
    window.addEventListener('DOMContentLoaded', () => {
      new CircularProgressBar({
        percent: <?php echo $d?>,
        pieName: 'piea',
        colorSlice: '#E91E63',
        time: 20
      });
     
    });
  </script>
</body>

</html>